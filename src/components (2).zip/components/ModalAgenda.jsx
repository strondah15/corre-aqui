'use client'

import { useState } from 'react'
import { ref, push, set, serverTimestamp } from 'firebase/database'
import { database } from '@/lib/firebase'

function tomorrow() {
  const d = new Date()
  d.setDate(d.getDate() + 1)
  return d.toISOString().slice(0, 10)
}

export default function ModalAgenda({
  open,
  onClose,
  profissional,
}) {
  const [data, setData] = useState(tomorrow())
  const [hora, setHora] = useState('09:00')
  const [duracao, setDuracao] = useState('1h')
  const [descricao, setDescricao] = useState('')
  const [valor, setValor] = useState('')
  const [salvando, setSalvando] = useState(false)
  const [enviado, setEnviado] = useState(false)

  if (!open || !profissional) return null

  const profissionalId = profissional.uid || profissional.id
  const profissionalNome =
    profissional.nome ||
    profissional.profile?.nome ||
    'Profissional'

  async function enviar() {
    if (!profissionalId || salvando) return

    setSalvando(true)

    try {
      const clienteId = localStorage.getItem('meuId') || ''
      const clienteNome = localStorage.getItem('meuNome') || 'Cliente'

      const novo = push(ref(database, 'agendamentos'))

      await set(novo, {
        profissionalId,
        profissionalNome,
        clienteId,
        clienteNome,
        data,
        hora,
        duracao,
        descricao,
        valor,
        status: 'pendente',
        criadoEm: Date.now(),
        atualizadoEm: serverTimestamp(),
      })

      setEnviado(true)
    } finally {
      setSalvando(false)
    }
  }

  return (
    <div className="fixed inset-0 z-[999999] flex items-center justify-center bg-black/70 backdrop-blur-md p-4">
      <div className="w-full max-w-[430px] overflow-hidden rounded-[32px] bg-white border border-white/60 shadow-[0_30px_90px_rgba(0,0,0,0.45)]">
        <div className="relative overflow-hidden bg-gradient-to-br from-violet-600 via-indigo-600 to-blue-700 px-5 py-5 text-white">
          <div className="absolute -top-10 -right-10 h-28 w-28 rounded-full bg-white/15 blur-2xl" />

          <div className="relative flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-[11px] font-black border border-white/10">
                📅 Agenda inteligente
              </div>

              <h2 className="mt-3 text-[24px] leading-none font-black">
                Agendar serviço
              </h2>

              <p className="mt-2 text-sm font-semibold text-white/85 truncate">
                com {profissionalNome}
              </p>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="h-10 w-10 shrink-0 rounded-2xl bg-white/15 hover:bg-white/25 border border-white/10 text-lg font-black transition"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="p-4 space-y-3">
          {enviado ? (
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-3">
              <div className="text-sm font-black text-emerald-800">
                ✅ Solicitação enviada
              </div>

              <div className="mt-1 text-xs font-semibold text-emerald-700">
                O profissional recebeu seu pedido de agendamento.
              </div>
            </div>
          ) : null}

          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="text-[11px] uppercase tracking-wide font-black text-slate-500">
                Data
              </span>

              <input
                type="date"
                value={data}
                onChange={(e) => setData(e.target.value)}
                className="mt-1.5 w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm font-bold outline-none focus:border-violet-400 focus:bg-white"
              />
            </label>

            <label className="block">
              <span className="text-[11px] uppercase tracking-wide font-black text-slate-500">
                Hora
              </span>

              <input
                type="time"
                value={hora}
                onChange={(e) => setHora(e.target.value)}
                className="mt-1.5 w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm font-bold outline-none focus:border-violet-400 focus:bg-white"
              />
            </label>
          </div>

          <label className="block">
            <span className="text-[11px] uppercase tracking-wide font-black text-slate-500">
              Duração estimada
            </span>

            <select
              value={duracao}
              onChange={(e) => setDuracao(e.target.value)}
              className="mt-1.5 w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm font-bold outline-none focus:border-violet-400 focus:bg-white"
            >
              <option>1h</option>
              <option>2h</option>
              <option>4h</option>
              <option>1 dia</option>
              <option>3 dias</option>
              <option>1 semana</option>
            </select>
          </label>

          <label className="block">
            <span className="text-[11px] uppercase tracking-wide font-black text-slate-500">
              Detalhes do serviço
            </span>

            <textarea
              rows={3}
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              placeholder="Ex: preciso instalar uma torneira..."
              className="mt-1.5 w-full resize-none rounded-2xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm font-semibold outline-none focus:border-violet-400 focus:bg-white"
            />
          </label>

          <label className="block">
            <span className="text-[11px] uppercase tracking-wide font-black text-slate-500">
              Valor opcional
            </span>

            <div className="mt-1.5 flex items-center rounded-2xl border border-slate-200 bg-slate-50 px-3">
              <span className="text-sm font-black text-slate-400">
                R$
              </span>

              <input
                value={valor}
                onChange={(e) => setValor(e.target.value)}
                placeholder="120"
                className="w-full bg-transparent px-2 py-3 text-sm font-bold outline-none"
              />
            </div>
          </label>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2 text-[11px] font-semibold text-slate-500">
            O pedido entra como <b className="text-slate-900">pendente</b> na agenda do profissional.
          </div>

          <button
            type="button"
            disabled={salvando}
            onClick={enviar}
            className="w-full rounded-[22px] bg-gradient-to-r from-violet-600 to-indigo-600 px-4 py-4 text-sm font-black text-white shadow-[0_14px_34px_rgba(99,102,241,0.30)] hover:opacity-95 active:scale-[0.98] transition disabled:opacity-60"
          >
            {salvando ? 'Enviando...' : 'Solicitar agendamento'}
          </button>
        </div>
      </div>
    </div>
  )
}
