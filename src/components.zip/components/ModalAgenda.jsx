'use client'

import { useState } from 'react'
import { ref, push, set, serverTimestamp } from 'firebase/database'
import { database } from '@/lib/firebase'

function tomorrow() {
  const d = new Date()
  d.setDate(d.getDate() + 1)
  return d.toISOString().slice(0, 10)
}

export default function ModalAgenda({
  open,
  onClose,
  profissional,
}) {
  const [data, setData] = useState(tomorrow())
  const [hora, setHora] = useState('09:00')
  const [duracao, setDuracao] = useState('1h')
  const [descricao, setDescricao] = useState('')
  const [valor, setValor] = useState('')
  const [salvando, setSalvando] = useState(false)
  const [enviado, setEnviado] = useState(false)

  if (!open || !profissional) return null

  const profissionalId = profissional.uid || profissional.id
  const profissionalNome = profissional.nome || profissional.profile?.nome || 'Profissional'

  async function enviar() {
    if (!profissionalId || salvando) return

    setSalvando(true)
    setEnviado(false)

    try {
      const clienteId = localStorage.getItem('meuId') || ''
      const clienteNome = localStorage.getItem('meuNome') || 'Cliente'

      const novo = push(ref(database, 'agendamentos'))
      await set(novo, {
        profissionalId,
        profissionalNome,
        clienteId,
        clienteNome,
        data,
        hora,
        duracao,
        descricao: descricao || `Agendamento solicitado para ${profissionalNome}`,
        valor,
        status: 'pendente',
        origem: 'modal_cliente',
        criadoEm: Date.now(),
        atualizadoEm: serverTimestamp(),
      })

      setEnviado(true)
      setDescricao('')
      setValor('')
    } finally {
      setSalvando(false)
    }
  }

  return (
    <div className="fixed inset-0 z-[100000] bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-3 md:p-5">
      <div className="w-full max-w-[430px] max-h-[92vh] overflow-hidden rounded-[32px] bg-white shadow-[0_30px_100px_rgba(0,0,0,0.48)] border border-white/70">
        <div className="relative overflow-hidden bg-gradient-to-br from-violet-600 via-indigo-600 to-blue-700 px-5 py-4 text-white">
          <div className="absolute -right-10 -top-12 h-28 w-28 rounded-full bg-white/15 blur-2xl" />
          <div className="absolute -left-8 bottom-0 h-20 w-20 rounded-full bg-cyan-300/20 blur-2xl" />

          <div className="relative flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="inline-flex items-center gap-2 rounded-full bg-white/14 border border-white/15 px-3 py-1 text-[11px] font-black text-white/90">
                📅 Agenda inteligente
              </div>

              <div className="mt-3 text-[24px] leading-none font-black tracking-tight">
                Agendar serviço
              </div>

              <div className="mt-1 text-sm font-semibold text-white/85 truncate">
                com {profissionalNome}
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="h-10 w-10 shrink-0 rounded-2xl bg-white/14 hover:bg-white/24 border border-white/10 font-black transition"
              aria-label="Fechar"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="max-h-[calc(92vh-112px)] overflow-y-auto p-4 md:p-5 space-y-3.5">
          {enviado ? (
            <div className="rounded-3xl bg-emerald-50 border border-emerald-200 p-3.5 text-emerald-800">
              <div className="font-black">✅ Solicitação enviada</div>
              <div className="mt-0.5 text-xs font-semibold text-emerald-700">
                O profissional vai receber e poderá aceitar ou recusar.
              </div>
            </div>
          ) : null}

          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="text-xs font-black uppercase tracking-wide text-slate-500">Data</span>
              <input
                type="date"
                value={data}
                onChange={(e) => setData(e.target.value)}
                className="mt-1.5 w-full rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-3 text-sm font-bold text-slate-900 outline-none focus:border-violet-400 focus:bg-white"
              />
            </label>

            <label className="block">
              <span className="text-xs font-black uppercase tracking-wide text-slate-500">Hora</span>
              <input
                type="time"
                value={hora}
                onChange={(e) => setHora(e.target.value)}
                className="mt-1.5 w-full rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-3 text-sm font-bold text-slate-900 outline-none focus:border-violet-400 focus:bg-white"
              />
            </label>
          </div>

          <label className="block">
            <span className="text-xs font-black uppercase tracking-wide text-slate-500">Duração estimada</span>
            <select
              value={duracao}
              onChange={(e) => setDuracao(e.target.value)}
              className="mt-1.5 w-full rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-3 text-sm font-bold text-slate-900 outline-none focus:border-violet-400 focus:bg-white"
            >
              <option>1h</option>
              <option>2h</option>
              <option>4h</option>
              <option>1 dia</option>
              <option>3 dias</option>
              <option>1 semana</option>
            </select>
          </label>

          <label className="block">
            <span className="text-xs font-black uppercase tracking-wide text-slate-500">Detalhes do serviço</span>
            <textarea
              rows={3}
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              placeholder="Ex: preciso instalar uma torneira..."
              className="mt-1.5 w-full resize-none rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-3 text-sm font-semibold text-slate-900 outline-none focus:border-violet-400 focus:bg-white"
            />
          </label>

          <label className="block">
            <span className="text-xs font-black uppercase tracking-wide text-slate-500">Valor opcional</span>
            <div className="mt-1.5 flex items-center rounded-2xl border border-slate-200 bg-slate-50 px-3.5 focus-within:border-violet-400 focus-within:bg-white">
              <span className="text-sm font-black text-slate-400">R$</span>
              <input
                value={valor}
                onChange={(e) => setValor(e.target.value)}
                placeholder="120"
                className="w-full bg-transparent px-2 py-3 text-sm font-bold text-slate-900 outline-none"
              />
            </div>
          </label>

          <div className="rounded-3xl bg-slate-50 border border-slate-200 p-3 text-xs font-semibold text-slate-500">
            O pedido entra como <b className="text-slate-800">pendente</b> na agenda do profissional.
          </div>

          <div className="sticky bottom-0 -mx-4 md:-mx-5 -mb-4 md:-mb-5 bg-white/92 backdrop-blur-xl border-t border-slate-100 p-4 md:p-5">
            <button
              type="button"
              disabled={salvando}
              onClick={enviar}
              className="w-full rounded-[24px] bg-gradient-to-r from-violet-600 to-indigo-600 px-5 py-4 text-white text-base font-black shadow-[0_14px_34px_rgba(99,102,241,0.30)] hover:opacity-95 active:scale-[0.98] disabled:opacity-60 transition"
            >
              {salvando ? 'Enviando...' : 'Solicitar agendamento'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
