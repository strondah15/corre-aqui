'use client'

import React from 'react'

/**
 * BottomBar (Pirâmide)
 * - modoApp: 'cliente' | 'corre'
 * - active: id da aba
 * - onTab: callback(id)
 * - unreadCount: número de não lidas
 * - hidden: esconde quando o mapa/modal estiver aberto (não ficar na frente)
 */
export default function BottomBar({ active, onTab, unreadCount = 0, hidden = false, modoApp = 'cliente' }) {
  if (hidden) return null

  const isCliente = modoApp === 'cliente'

  const leftTop = isCliente
    ? { id: 'cliente', label: 'Pedir', icon: '🧭' }
    : { id: 'corre', label: 'Trabalhos', icon: '🎯' }

  const leftBottom = { id: 'inbox', label: 'Inbox', icon: '💬' }
  const rightTop = { id: 'aovivo', label: 'Mapa', icon: '🗺️' }
  const rightBottom = { id: 'perfil', label: 'Perfil', icon: '👤' }

  const center = isCliente
    ? { id: 'criar', label: 'Criar', icon: '➕' }
    : { id: 'criar', label: 'Disponível', icon: '🟢' }

  const btn = (item, extra = '') => {
    const isActive = active === item.id
    return (
      <button
        type="button"
        onClick={() => onTab?.(item.id)}
        className={[
          'w-[96px] h-[56px] rounded-3xl border flex items-center justify-center gap-2 transition shadow-[0_16px_45px_rgba(0,0,0,0.22)] backdrop-blur-xl',
          'active:scale-[0.98]',
          isActive ? 'bg-white text-slate-950 border-white' : 'bg-slate-900/70 text-white border-white/10 hover:bg-slate-800/80',
          extra,
        ].join(' ')}
        aria-pressed={isActive}
      >
        <span className="text-lg">{item.icon}</span>
        <span className="text-[12px] font-semibold">{item.label}</span>
      </button>
    )
  }

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[9998]">
      <div className="relative w-[340px]">
        {/* coluna esquerda */}
        <div className="absolute left-0 bottom-0 flex flex-col gap-2">
          {btn(leftTop)}
          {btn(leftBottom)}
        </div>

        {/* coluna direita */}
        <div className="absolute right-0 bottom-0 flex flex-col gap-2">
          {btn(rightTop)}
          {btn(rightBottom)}
        </div>

        {/* centro (topo da pirâmide) */}
        <div className="mx-auto w-[140px]">
          <button
            type="button"
            onClick={() => onTab?.(center.id)}
            className={[
              'w-full h-[68px] rounded-[28px] border text-white flex flex-col items-center justify-center gap-1 transition',
              'active:scale-[0.98] shadow-[0_18px_60px_rgba(0,0,0,0.28)]',
              'bg-gradient-to-b from-emerald-400 to-emerald-600 border-emerald-300/40 hover:from-emerald-300',
              active === center.id ? 'ring-2 ring-white/50' : '',
            ].join(' ')}
          >
            <div className="text-2xl">{center.icon}</div>
            <div className="text-[12px] font-extrabold tracking-wide">{center.label}</div>
          </button>
        </div>

        {/* badge inbox */}
        {unreadCount > 0 && (
          <div className="absolute left-[92px] bottom-[56px]">
            <div className="min-w-[22px] h-[22px] px-1 rounded-full bg-amber-400 text-black text-[12px] font-extrabold flex items-center justify-center border border-amber-200 shadow">
              {unreadCount > 99 ? '99+' : unreadCount}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
